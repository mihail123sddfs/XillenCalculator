#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deadly's Scientific Calculator
Научный калькулятор с графическим интерфейсом
Автор: Deadly
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import re

class ScientificCalculator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🧮 Deadly's Scientific Calculator")
        self.root.geometry("600x700")
        self.root.configure(bg='#1a1a2e')
        
        self.current_input = ""
        self.history = []
        
        self.setup_ui()
        
    def setup_ui(self):
        # Создаем notebook для вкладок
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Вкладка калькулятора
        self.calc_frame = tk.Frame(self.notebook, bg='#1a1a2e')
        self.notebook.add(self.calc_frame, text="🧮 Калькулятор")
        
        # Вкладка графиков
        self.graph_frame = tk.Frame(self.notebook, bg='#1a1a2e')
        self.notebook.add(self.graph_frame, text="📊 Графики")
        
        self.setup_calculator()
        self.setup_graphs()
        
    def setup_calculator(self):
        # Дисплей
        display_frame = tk.Frame(self.calc_frame, bg='#1a1a2e')
        display_frame.pack(pady=10)
        
        self.display = tk.Entry(
            display_frame,
            font=("Arial", 20, "bold"),
            width=25,
            bg='#16213e',
            fg='white',
            insertbackground='white',
            justify='right',
            state='readonly'
        )
        self.display.pack()
        
        # История
        history_frame = tk.Frame(self.calc_frame, bg='#1a1a2e')
        history_frame.pack(pady=5)
        
        history_label = tk.Label(
            history_frame,
            text="📜 История:",
            font=("Arial", 12, "bold"),
            fg='#00ff88',
            bg='#1a1a2e'
        )
        history_label.pack()
        
        self.history_listbox = tk.Listbox(
            history_frame,
            height=4,
            bg='#16213e',
            fg='white',
            font=("Arial", 10)
        )
        self.history_listbox.pack(fill=tk.X)
        
        # Кнопки
        buttons_frame = tk.Frame(self.calc_frame, bg='#1a1a2e')
        buttons_frame.pack(pady=10)
        
        # Создаем кнопки
        buttons = [
            ['C', 'CE', '⌫', '÷'],
            ['7', '8', '9', '×'],
            ['4', '5', '6', '-'],
            ['1', '2', '3', '+'],
            ['0', '.', '±', '='],
            ['sin', 'cos', 'tan', '√'],
            ['log', 'ln', 'π', 'e'],
            ['x²', 'x³', 'x^y', '!'],
            ['(', ')', 'mod', '1/x']
        ]
        
        for i, row in enumerate(buttons):
            for j, text in enumerate(row):
                btn = tk.Button(
                    buttons_frame,
                    text=text,
                    font=("Arial", 12, "bold"),
                    width=6,
                    height=2,
                    command=lambda t=text: self.button_click(t),
                    bg=self.get_button_color(text),
                    fg='white'
                )
                btn.grid(row=i, column=j, padx=2, pady=2)
                
    def get_button_color(self, text):
        if text in ['C', 'CE', '⌫']:
            return '#ff4444'
        elif text in ['÷', '×', '-', '+', '=']:
            return '#00ff88'
        elif text in ['sin', 'cos', 'tan', '√', 'log', 'ln', 'π', 'e', 'x²', 'x³', 'x^y', '!', 'mod', '1/x']:
            return '#4444ff'
        else:
            return '#333333'
            
    def setup_graphs(self):
        # Функция для построения графика
        func_frame = tk.Frame(self.graph_frame, bg='#1a1a2e')
        func_frame.pack(pady=10)
        
        tk.Label(
            func_frame,
            text="📊 Построение графиков",
            font=("Arial", 16, "bold"),
            fg='#00ff88',
            bg='#1a1a2e'
        ).pack()
        
        tk.Label(
            func_frame,
            text="Введите функцию (например: sin(x), x**2, log(x)):",
            font=("Arial", 10),
            fg='white',
            bg='#1a1a2e'
        ).pack(pady=5)
        
        self.func_entry = tk.Entry(
            func_frame,
            font=("Arial", 12),
            width=30,
            bg='#16213e',
            fg='white',
            insertbackground='white'
        )
        self.func_entry.pack(pady=5)
        
        tk.Button(
            func_frame,
            text="📈 Построить график",
            command=self.plot_function,
            bg='#00ff88',
            fg='black',
            font=("Arial", 10, "bold"),
            padx=20
        ).pack(pady=10)
        
        # Область для графика
        self.graph_canvas_frame = tk.Frame(self.graph_frame, bg='#1a1a2e')
        self.graph_canvas_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
    def button_click(self, text):
        if text == 'C':
            self.current_input = ""
            self.update_display()
        elif text == 'CE':
            self.current_input = ""
            self.update_display()
        elif text == '⌫':
            self.current_input = self.current_input[:-1]
            self.update_display()
        elif text == '=':
            self.calculate()
        elif text == '±':
            if self.current_input.startswith('-'):
                self.current_input = self.current_input[1:]
            else:
                self.current_input = '-' + self.current_input
            self.update_display()
        else:
            self.current_input += text
            self.update_display()
            
    def update_display(self):
        self.display.config(state='normal')
        self.display.delete(0, tk.END)
        self.display.insert(0, self.current_input)
        self.display.config(state='readonly')
        
    def calculate(self):
        try:
            # Заменяем символы для Python
            expression = self.current_input.replace('×', '*').replace('÷', '/')
            expression = expression.replace('π', str(math.pi)).replace('e', str(math.e))
            
            # Обрабатываем специальные функции
            expression = self.process_functions(expression)
            
            result = eval(expression)
            
            # Добавляем в историю
            history_item = f"{self.current_input} = {result}"
            self.history.append(history_item)
            self.history_listbox.insert(tk.END, history_item)
            self.history_listbox.see(tk.END)
            
            self.current_input = str(result)
            self.update_display()
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Неверное выражение: {str(e)}")
            
    def process_functions(self, expression):
        # Обрабатываем математические функции
        functions = {
            'sin': 'math.sin',
            'cos': 'math.cos', 
            'tan': 'math.tan',
            'log': 'math.log10',
            'ln': 'math.log',
            '√': 'math.sqrt',
            'mod': '%'
        }
        
        for func, replacement in functions.items():
            expression = expression.replace(func, replacement)
            
        # Обрабатываем степени
        expression = re.sub(r'(\d+)²', r'\1**2', expression)
        expression = re.sub(r'(\d+)³', r'\1**3', expression)
        expression = re.sub(r'(\d+)\^(\d+)', r'\1**\2', expression)
        
        # Обрабатываем факториал
        def factorial_replace(match):
            num = int(match.group(1))
            return str(math.factorial(num))
        expression = re.sub(r'(\d+)!', factorial_replace, expression)
        
        # Обрабатываем обратное число
        expression = re.sub(r'1/(\d+)', r'1/\1', expression)
        
        return expression
        
    def plot_function(self):
        try:
            func_str = self.func_entry.get().strip()
            if not func_str:
                messagebox.showwarning("Предупреждение", "Введите функцию!")
                return
                
            # Очищаем предыдущий график
            for widget in self.graph_canvas_frame.winfo_children():
                widget.destroy()
                
            # Создаем новый график
            fig, ax = plt.subplots(figsize=(8, 6))
            fig.patch.set_facecolor('#1a1a2e')
            ax.set_facecolor('#16213e')
            
            # Подготавливаем функцию
            func_str = func_str.replace('^', '**')
            func_str = func_str.replace('sin', 'np.sin')
            func_str = func_str.replace('cos', 'np.cos')
            func_str = func_str.replace('tan', 'np.tan')
            func_str = func_str.replace('log', 'np.log10')
            func_str = func_str.replace('ln', 'np.log')
            func_str = func_str.replace('sqrt', 'np.sqrt')
            
            # Создаем массив x
            x = np.linspace(-10, 10, 1000)
            
            # Вычисляем y
            y = eval(func_str)
            
            # Строим график
            ax.plot(x, y, color='#00ff88', linewidth=2)
            ax.grid(True, alpha=0.3, color='white')
            ax.set_xlabel('x', color='white')
            ax.set_ylabel('y', color='white')
            ax.set_title(f'График функции: {self.func_entry.get()}', color='white')
            ax.tick_params(colors='white')
            
            # Встраиваем график в tkinter
            canvas = FigureCanvasTkAgg(fig, self.graph_canvas_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка построения графика: {str(e)}")
            
    def run(self):
        self.root.mainloop()

def main():
    print("🧮 Запуск Scientific Calculator...")
    app = ScientificCalculator()
    app.run()

if __name__ == "__main__":
    main()
